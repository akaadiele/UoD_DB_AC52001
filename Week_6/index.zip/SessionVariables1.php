<!-- Session Variables -->
<!-- To destroy a session (e.g. on logout, or if you are finished with the data being stored) use: -->
<?php
session_destroy();
?>