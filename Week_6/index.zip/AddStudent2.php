<html>
<form name="Add New Student" action="form2.php" method="post">
    Firstname:<input type="text" name="firstname">
    Surname: <input type="text" name="surname">
    <input type="submit" name="submit" value="submit" />
</form>

</html>