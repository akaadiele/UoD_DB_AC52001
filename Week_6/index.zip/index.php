<html>
	<head>
	</head>
	<body>
		<?php
			// PHP code goes here
			echo "Hello World <br>";
			// Declare a variable – use YOUR name
			$name = "Aka";
			echo "My name is ".$name."<br>";
		?>
	</body>
</html>